import { TransactionReceipt, TransactionResponse } from "ethers";
import fs from "fs";

import * as toml from "@iarna/toml";

import { IDualGovernance, IEmergencyProtectedTimelock } from "typechain-types";

import { advanceChainTime, ether, log } from "lib";
import { impersonate } from "lib/account";
import { UpgradeParameters, validateUpgradeParameters } from "lib/config-schemas";
import { loadContract } from "lib/contract";
import { DeploymentState, getAddress, Sk } from "lib/state-file";

import { ONE_HOUR } from "test/suite";

const FUSAKA_TX_LIMIT = 2n ** 24n; // 16M =  16_777_216

const UPGRADE_PARAMETERS_FILE = process.env.UPGRADE_PARAMETERS_FILE;

export { UpgradeParameters };

export function readUpgradeParameters(skipValidation: boolean = false): UpgradeParameters {
  if (!UPGRADE_PARAMETERS_FILE) {
    throw new Error("UPGRADE_PARAMETERS_FILE is not set");
  }

  if (!fs.existsSync(UPGRADE_PARAMETERS_FILE)) {
    throw new Error(`Upgrade parameters file not found: ${UPGRADE_PARAMETERS_FILE}`);
  }

  const rawData = fs.readFileSync(UPGRADE_PARAMETERS_FILE, "utf8");
  const parsedData = toml.parse(rawData);

  if (skipValidation) {
    return parsedData as UpgradeParameters;
  }

  try {
    return validateUpgradeParameters(parsedData);
  } catch (error) {
    throw new Error(`Invalid upgrade parameters (${UPGRADE_PARAMETERS_FILE}): ${error}`);
  }
}

export async function mockDGAragonVoting(state: DeploymentState): Promise<{
  proposalId: bigint;
  scheduleReceipt: TransactionReceipt;
  proposalExecutedReceipt: TransactionReceipt;
}> {
  log("Starting mock Aragon voting...");
  const agentAddress = getAddress(Sk.appAgent, state);

  const deployer = await impersonate(agentAddress, ether("100"));
  const timelock = await loadContract<IEmergencyProtectedTimelock>(
    "IEmergencyProtectedTimelock",
    state[Sk.dgEmergencyProtectedTimelock].proxy.address,
  );
  const afterSubmitDelay = await timelock.getAfterSubmitDelay();
  const afterScheduleDelay = await timelock.getAfterScheduleDelay();

  const dualGovernance = await loadContract<IDualGovernance>(
    "IDualGovernance",
    state[Sk.dgDualGovernance].proxy.address,
  );

  const proposalId = 6n; // https://dg.lido.fi/proposals/6
  log.success("Proposal submitted: proposalId", proposalId);

  await advanceChainTime(afterSubmitDelay);
  const scheduleTx = await dualGovernance.connect(deployer).scheduleProposal(proposalId);
  const scheduleReceipt = (await scheduleTx.wait())!;
  log.success("Proposal scheduled: gas used", scheduleReceipt.gasUsed);

  await advanceChainTime(afterScheduleDelay);
  let proposalExecutedTx: TransactionResponse;
  let revertedDueToTimeConstraints: boolean = true;
  let attempts: number = 0;

  while (revertedDueToTimeConstraints && attempts < 24) {
    try {
      proposalExecutedTx = await timelock.connect(deployer).execute(proposalId);
      revertedDueToTimeConstraints = false;
    } catch {
      await advanceChainTime(ONE_HOUR);
      attempts++;
    }
  }

  const proposalExecutedReceipt = (await proposalExecutedTx!.wait())!;
  log.success("Proposal executed: gas used", proposalExecutedReceipt.gasUsed);

  if (proposalExecutedReceipt.gasUsed > FUSAKA_TX_LIMIT) {
    log.error("Proposal executed: gas used exceeds FUSAKA_TX_LIMIT");
    process.exit(1);
  }

  return { proposalId, scheduleReceipt, proposalExecutedReceipt };
}
